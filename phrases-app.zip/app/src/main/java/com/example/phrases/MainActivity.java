package com.example.phrases;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final int GREEN = 0xFF3DDC5A, YELLOW = 0xFFFFD93D, GRAY = 0xFF8A8A8A;
    ArrayList<String[]> pairs = new ArrayList<>();
    int idx = 0;
    String raw = "";
    PhraseView pv;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("s", MODE_PRIVATE);
        float d = getResources().getDisplayMetrics().density;
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams wp = getWindow().getAttributes();
            wp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(wp);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnClickListener(v -> next());

        pv = new PhraseView(this);
        root.addView(pv, new FrameLayout.LayoutParams(-1, -1));

        TextView btn = new TextView(this);
        btn.setText("📋");
        btn.setTextSize(15);
        btn.setAlpha(0.35f);
        int bp = (int) (14 * d);
        btn.setPadding(bp, bp, bp, bp);
        btn.setOnClickListener(v -> paste());
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        bl.bottomMargin = (int) (12 * d);
        root.addView(btn, bl);
        setContentView(root);
        immersive();

        raw = prefs.getString("t", "");
        pairs = parse(raw);
        idx = Math.min(prefs.getInt("i", 0), Math.max(pairs.size() - 1, 0));
        show();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    void paste() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData cd = cm.getPrimaryClip();
        if (cd == null || cd.getItemCount() == 0) return;
        CharSequence t = cd.getItemAt(0).coerceToText(this);
        if (t == null) return;
        ArrayList<String[]> p = parse(t.toString());
        if (p.isEmpty()) return;
        raw = t.toString();
        pairs = p;
        idx = 0;
        save();
        show();
    }

    void next() {
        if (pairs.isEmpty()) return;
        idx = (idx + 1) % pairs.size();
        save();
        show();
    }

    void save() {
        prefs.edit().putString("t", raw).putInt("i", idx).apply();
    }

    void show() {
        if (pairs.isEmpty()) {
            pv.set("انسخ النص ثم اضغط زر اللصق في الركن السفلي الأيسر", "", GRAY);
            return;
        }
        String[] p = pairs.get(idx);
        pv.set(p[0], p[1], GREEN);
    }

    static ArrayList<String[]> parse(String t) {
        ArrayList<String[]> out = new ArrayList<>();
        ArrayList<String> g = new ArrayList<>();
        for (String l : t.replace("\r", "").split("\n")) {
            l = l.trim();
            if (!l.isEmpty()) g.add(l);
            else flush(g, out);
        }
        flush(g, out);
        return out;
    }

    static void flush(ArrayList<String> g, ArrayList<String[]> out) {
        for (int i = 0; i < g.size(); i += 2)
            out.add(new String[]{g.get(i), i + 1 < g.size() ? g.get(i + 1) : ""});
        g.clear();
    }

    // يرسم النص كأشكال (Path) عشان خاصية "تباين النص العالي" في الموبايل متغيرش الألوان
    class PhraseView extends View {
        String a = "", b = "";
        int ca = GREEN;
        final TextPaint pa = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        final TextPaint pb = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path path = new Path();
        final float d = getResources().getDisplayMetrics().density;

        PhraseView(Context c) {
            super(c);
            pa.setTypeface(Typeface.DEFAULT_BOLD);
            pb.setTypeface(Typeface.DEFAULT);
            pa.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 42, getResources().getDisplayMetrics()));
            pb.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 36, getResources().getDisplayMetrics()));
            fill.setStyle(Paint.Style.FILL);
        }

        void set(String x, String y, int c) {
            a = x;
            b = y;
            ca = c;
            invalidate();
        }

        StaticLayout lay(String s, TextPaint p, int w) {
            return new StaticLayout(s, p, w, Layout.Alignment.ALIGN_CENTER, 1.15f, 0f, false);
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth() - (int) (48 * d);
            if (w <= 0) return;
            StaticLayout la = lay(a, pa, w), lb = lay(b, pb, w);
            float gap = b.isEmpty() ? 0 : 44 * d;
            float top = (getHeight() - (la.getHeight() + gap + lb.getHeight())) / 2f;
            paintLines(c, la, pa, a, ca, top);
            paintLines(c, lb, pb, b, YELLOW, top + la.getHeight() + gap);
        }

        void paintLines(Canvas c, StaticLayout l, TextPaint p, String s, int color, float top) {
            fill.setColor(color);
            float left = 24 * d;
            for (int i = 0; i < l.getLineCount(); i++) {
                path.rewind();
                p.getTextPath(s, l.getLineStart(i), l.getLineEnd(i),
                        left + l.getLineLeft(i), top + l.getLineBaseline(i), path);
                c.drawPath(path, fill);
            }
        }
    }
}
