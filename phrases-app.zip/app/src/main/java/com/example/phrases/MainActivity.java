package com.example.phrases;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final int GREEN = 0xFF3DDC5A, YELLOW = 0xFFFFD93D, GRAY = 0xFF777777;
    ArrayList<String[]> pairs = new ArrayList<>();
    int idx = 0;
    String raw = "";
    TextView es, en;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("s", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        float d = getResources().getDisplayMetrics().density;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnClickListener(v -> next());

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int pad = (int) (24 * d);
        box.setPadding(pad, pad, pad, pad);
        es = tv(GREEN, 42, true);
        es.setPadding(0, 0, 0, (int) (44 * d));
        en = tv(YELLOW, 36, false);
        box.addView(es);
        box.addView(en);
        root.addView(box, new FrameLayout.LayoutParams(-1, -1));

        TextView btn = new TextView(this);
        btn.setText("📋");
        btn.setTextSize(15);
        btn.setAlpha(0.35f);
        int bp = (int) (14 * d);
        btn.setPadding(bp, bp, bp, bp);
        btn.setOnClickListener(v -> paste());
        root.addView(btn, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT));
        setContentView(root);

        raw = prefs.getString("t", "");
        pairs = parse(raw);
        idx = Math.min(prefs.getInt("i", 0), Math.max(pairs.size() - 1, 0));
        show();
    }

    TextView tv(int color, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(0, 0, 0, (int) (12 * getResources().getDisplayMetrics().density));
        return t;
    }

    void paste() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData cd = cm.getPrimaryClip();
        if (cd == null || cd.getItemCount() == 0) return;
        CharSequence t = cd.getItemAt(0).coerceToText(this);
        if (t == null) return;
        ArrayList<String[]> p = parse(t.toString());
        if (p.isEmpty()) return;
        raw = t.toString();
        pairs = p;
        idx = 0;
        save();
        show();
    }

    void next() {
        if (pairs.isEmpty()) return;
        idx = (idx + 1) % pairs.size();
        save();
        show();
    }

    void save() {
        prefs.edit().putString("t", raw).putInt("i", idx).apply();
    }

    void show() {
        if (pairs.isEmpty()) {
            es.setTextColor(GRAY);
            es.setText("انسخ النص ثم اضغط زر اللصق في الركن السفلي الأيسر");
            en.setText("");
            return;
        }
        String[] p = pairs.get(idx);
        es.setTextColor(GREEN);
        es.setText(p[0]);
        en.setText(p[1]);
    }

    static ArrayList<String[]> parse(String t) {
        ArrayList<String[]> out = new ArrayList<>();
        ArrayList<String> g = new ArrayList<>();
        for (String l : t.replace("\r", "").split("\n")) {
            l = l.trim();
            if (!l.isEmpty()) g.add(l);
            else flush(g, out);
        }
        flush(g, out);
        return out;
    }

    static void flush(ArrayList<String> g, ArrayList<String[]> out) {
        for (int i = 0; i < g.size(); i += 2)
            out.add(new String[]{g.get(i), i + 1 < g.size() ? g.get(i + 1) : ""});
        g.clear();
    }
}
